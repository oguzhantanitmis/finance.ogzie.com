var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/route.js")
R.c("server/chunks/[root-of-the-server]__35c46238._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_6cd239df.js")
R.c("server/chunks/[root-of-the-server]__24f8fcd9._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_route_actions_9ece58bc.js")
R.m(37291)
module.exports=R.m(37291).exports
