globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/6e0dee5b6681763c.js",
    "static/chunks/1627bf2f54f2038d.js",
    "static/chunks/18bf4b74296a623f.js",
    "static/chunks/30fbcf50b504a889.js",
    "static/chunks/turbopack-9830ba978d67383c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];